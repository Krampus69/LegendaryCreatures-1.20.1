package sfiomn.legendarycreatures.events;

import com.realgecko.xpfromharvest.ModConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import sfiomn.legendarycreatures.config.Config;
import sfiomn.legendarycreatures.registry.EntityTypeRegistry;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.tags.IReverseTag;
import sfiomn.legendarycreatures.LegendaryCreatures;
import sfiomn.legendarycreatures.api.entities.MobEntityEnum;
import sfiomn.legendarycreatures.config.BlackLists;
import sfiomn.legendarycreatures.config.json.JsonChanceSpawn;
import sfiomn.legendarycreatures.config.json.JsonConfig;
import sfiomn.legendarycreatures.entities.AnimatedCreatureEntity;
import sfiomn.legendarycreatures.items.StrawHatItem;
import sfiomn.legendarycreatures.util.DamageSourceUtil;
import sfiomn.legendarycreatures.util.WorldUtil;
import net.minecraftforge.event.RegisterCommandsEvent;
import sfiomn.legendarycreatures.commands.SummonRarityCommand;

import java.util.*;

@Mod.EventBusSubscriber(modid = LegendaryCreatures.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ForgeEvents {

    private static final String SCARECROW_IMMUNITY_KEY = LegendaryCreatures.MOD_ID + ":scarecrow_immunity_until";
    private static final long SCARECROW_IMMUNITY_TICKS = 2400L;

    private static boolean hasScarecrowImmunity(Player player) {
        return player.level().getGameTime() < player.getPersistentData().getLong(SCARECROW_IMMUNITY_KEY);
    }

    private static void applyScarecrowImmunity(Player player) {
        player.getPersistentData().putLong(SCARECROW_IMMUNITY_KEY,
                player.level().getGameTime() + SCARECROW_IMMUNITY_TICKS);
    }


    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (event.getPlayer().isCreative() ||
                event.getPlayer().isSpectator() ||
                !event.getState().getBlock().canHarvestBlock(event.getState(), event.getLevel(), event.getPos(), event.getPlayer()))
            return;

        handleBreakBlock(event.getLevel(), event.getState(), event.getPos(), event.getPlayer());
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        SummonRarityCommand.register(event.getDispatcher(), event.getBuildContext());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onBlockRightClick(PlayerInteractEvent.RightClickBlock event) {
        if (event.getEntity().isCreative() ||
                event.getEntity().isSpectator())
            return;

        if (LegendaryCreatures.xpFromHarvestLoaded && ModConfig.simpleHarvest.get()) {
            if (event.getEntity() == null || event.getLevel().isClientSide())
                return;

            Level level = event.getLevel();
            BlockPos pos = event.getPos();
            BlockState state = level.getBlockState(pos);

            if (ModConfig.crops.get().contains(state.toString())) {
                handleBreakBlock(level, state, pos, event.getEntity());
            }
        }
    }

    @SubscribeEvent
    public static void onEntityKilled(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof Player player) {
            ResourceLocation killedEntityName = ForgeRegistries.ENTITY_TYPES.getKey(event.getEntity().getType());

            Optional<IReverseTag<EntityType<?>>> entityTypeTagsOptional = Objects.requireNonNull(ForgeRegistries.ENTITY_TYPES.tags()).getReverseTag(event.getEntity().getType());
            IReverseTag<EntityType<?>> entityTypeTags = null;
            if (entityTypeTagsOptional.isPresent())
                entityTypeTags = entityTypeTagsOptional.get();

            if (player.isCreative() || player.isSpectator() || killedEntityName == null)
                return;

            for (MobEntityEnum mobEntityEnum : MobEntityEnum.values()) {
                String mobId = mobEntityEnum.mobId;
                BlackLists blackLists = JsonConfig.mobIdSpawnList.get(mobId).blackLists;

                Map<String, JsonChanceSpawn> killingEntityNameSpawns = JsonConfig.mobIdSpawnList.get(mobId).killingEntityNameSpawns;
                Map<TagKey<EntityType<?>>, JsonChanceSpawn> killingEntityTagSpawns = JsonConfig.mobIdSpawnList.get(mobId).killingEntityTypeTagSpawns;

                boolean cancelSpawn = false;
                if (blackLists.killingEntityNames.contains(killedEntityName.toString())) {
                    cancelSpawn = true;
                }
                else if (entityTypeTags != null)
                    for (TagKey<EntityType<?>> blackListedEntityTypeTag : blackLists.killingEntityTypeTags) {
                        if (entityTypeTags.containsTag(blackListedEntityTypeTag)) {
                            cancelSpawn = true;
                        }
                    }
                if (cancelSpawn)
                    continue;

                if (killingEntityNameSpawns.containsKey(killedEntityName.toString())) {
                    if (spawnEntity(event.getEntity().getCommandSenderWorld(), event.getEntity().position(), mobEntityEnum, killingEntityNameSpawns.get(killedEntityName.toString()).chance)) {
                        return;
                    }
                } else if (entityTypeTags != null) {
                    boolean tagFound = false;
                    for (TagKey<EntityType<?>> spawnKillingEntityTypeTag: killingEntityTagSpawns.keySet()) {
                        if (entityTypeTags.containsTag(spawnKillingEntityTypeTag)) {
                            tagFound = true;
                            if (spawnEntity(event.getEntity().getCommandSenderWorld(), event.getEntity().position(), mobEntityEnum, killingEntityTagSpawns.get(spawnKillingEntityTypeTag).chance)) {
                                return;
                            }
                        }
                    }
                    if (!tagFound && killingEntityNameSpawns.containsKey("default")) {
                        if (spawnEntity(event.getEntity().getCommandSenderWorld(), event.getEntity().position(), mobEntityEnum, killingEntityNameSpawns.get("default").chance)) {
                            return;
                        }
                    }
                }
            }
        }
    }

    private static void handleBreakBlock(LevelAccessor level, BlockState state, BlockPos pos, Player player) {

        ResourceLocation blockRegistryName = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (blockRegistryName == null) {
            return;
        }

        Vec3 spawnPos = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);

        Optional<IReverseTag<Block>> blockTagsOptional = Objects.requireNonNull(ForgeRegistries.BLOCKS.tags()).getReverseTag(state.getBlock());
        IReverseTag<Block> blockTags = null;
        if (blockTagsOptional.isPresent())
            blockTags = blockTagsOptional.get();

        boolean isStrawHatWorn = (player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof StrawHatItem);

        for (MobEntityEnum mobEntityEnum : MobEntityEnum.values()) {

            String mobId = mobEntityEnum.mobId;
            String blockName = blockRegistryName.toString();

            BlackLists blackLists = JsonConfig.mobIdSpawnList.get(mobId).blackLists;

            Map<String, JsonChanceSpawn> breakingBlockNameSpawns = JsonConfig.mobIdSpawnList.get(mobId).breakingBlockNameSpawns;
            Map<TagKey<Block>, JsonChanceSpawn> breakingBlockTagSpawns = JsonConfig.mobIdSpawnList.get(mobId).breakingBlockTagSpawns;

            boolean cancelSpawn = false;
            if (blackLists.breakingBlockNames.contains(blockName)) {
                cancelSpawn = true;
            }
            else if (blockTags != null) {
                for (TagKey<Block> blackListedBlockTag : blackLists.breakingBlockTags) {
                    if (blockTags.containsTag(blackListedBlockTag)) {
                        cancelSpawn = true;
                    }
                }
            }
            if (cancelSpawn)
                continue;

            double spawnChance = 0;
            if (breakingBlockNameSpawns.containsKey(blockRegistryName.toString()))
                spawnChance = breakingBlockNameSpawns.get(blockRegistryName.toString()).chance;

            if (spawnChance <= 0 && breakingBlockNameSpawns.containsKey("default"))
                spawnChance = breakingBlockNameSpawns.get("default").chance;

            if (spawnChance <= 0 && blockTags != null) {
                for (TagKey<Block> spawnBlockTag : breakingBlockTagSpawns.keySet()) {
                    if (blockTags.containsTag(spawnBlockTag)) {
                        spawnChance = breakingBlockTagSpawns.get(spawnBlockTag).chance;
                    }
                }
            }

            if (spawnChance > 0) {
                if (mobEntityEnum == MobEntityEnum.SCARECROW && isStrawHatWorn) {
                    if (level instanceof Level)
                        player.getInventory().hurtArmor(DamageSourceUtil.getDamageSource((Level) level, DamageTypes.GENERIC),1, Inventory.HELMET_SLOT_ONLY);
                    continue;
                }

                if (mobEntityEnum == MobEntityEnum.SCARECROW && hasScarecrowImmunity(player))
                    continue;

                if (spawnEntity(level, spawnPos, mobEntityEnum, spawnChance)) {
                    if (mobEntityEnum == MobEntityEnum.SCARECROW)
                        applyScarecrowImmunity(player);
                    return;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        // Only block natural and chunk generation spawns - not spawn eggs or /summon
        MobSpawnType spawnType = event.getSpawnType();
        if (spawnType != MobSpawnType.NATURAL && spawnType != MobSpawnType.CHUNK_GENERATION)
            return;

        EntityType<?> type = event.getEntity().getType();

        if (type == EntityTypeRegistry.DESERT_MOJO.get() && !Config.Baked.desertMojoNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.FOREST_MOJO.get() && !Config.Baked.forestMojoNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.HOUND.get() && !Config.Baked.houndNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.SCARECROW.get() && !Config.Baked.scarecrowNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.SCORPION.get() && !Config.Baked.scorpionNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.SCORPION_BABY.get() && !Config.Baked.scorpionBabyNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.CORPSE_EATER.get() && !Config.Baked.corpseEaterNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.PEACOCK_SPIDER.get() && !Config.Baked.peacockSpiderNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.BULLFROG.get() && !Config.Baked.bullfrogNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.WISP.get() && !Config.Baked.wispNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.NETHER_WISP.get() && !Config.Baked.netherWispNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.ENDER_WISP.get() && !Config.Baked.enderWispNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.BUTTERFLY.get() && !Config.Baked.butterflyNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.DRAGONFLY.get() && !Config.Baked.dragonflyNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.LADYBUG.get() && !Config.Baked.ladybugNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.SCARAB.get() && !Config.Baked.scarabNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.MANTIS.get() && !Config.Baked.mantisNaturalSpawn) { event.setSpawnCancelled(true); }
        else if (type == EntityTypeRegistry.HERMIT_CRAB.get() && !Config.Baked.hermitCrabNaturalSpawn) { event.setSpawnCancelled(true); }
    }

    private static boolean spawnEntity(LevelAccessor level, Vec3 pos, MobEntityEnum mobEntityEnum, double chance) {
        RandomSource rand = level.getRandom();

        if (rand.nextFloat() < chance) {
            EntityType<?> entityType = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(LegendaryCreatures.MOD_ID, mobEntityEnum.mobId));
            if (entityType != null) {
                Entity entityToSpawn = entityType.create((Level) level);
                if (entityToSpawn != null) {
                    if (entityToSpawn instanceof AnimatedCreatureEntity animEntity)
                        animEntity.setSpawnEffect(true);
                    WorldUtil.spawnEntity(entityToSpawn, level, pos);
                    return true;
                }
            }
        }
        return false;
    }
}